﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_Multiples
{
    class Program
    {
        static void Main(string[] args)
        {
            //for loop to iterate from 1-100
            for(int i = 1; i <= 100; i++)
            {
                //use a nested if statement to check the following conditions
                if (i % 15 == 0) //check whether the number is a multiple of both 3 and 5 then print "FizzBuzz"
                {
                    Console.WriteLine("FizzBuz");
                }
                else if (i % 5 == 0) //check whether the number is a multiple of 5 then print "Buzz"
                {
                    Console.WriteLine("Buzz");
                }
                else if (i % 3 == 0 ) //check whether the number is a multiple of 3 then print "Fizz"
                {
                    Console.WriteLine("Fizz");
                }
                else
                {
                    Console.WriteLine(i); //print numbers that do not fall under the above conditions
                }
            }
            Console.ReadKey();
        }
    }
}
